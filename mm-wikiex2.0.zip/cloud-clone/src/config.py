# coding: utf8
'''
    @author: Simon
'''

class Config():
    HOST = "0.0.0.0"
    PORT = 8885
    '''For Example：./repo or /data/repo'''        
    FILE_ROOT = "E:/Test/temp-cloud-clone"