package global

const (
	SYSTEM_VERSION   = "v0.2.2"              // system version code
	SYSTEM_COPYRIGHT = "2018 - 2022 phachon" // system copyright
)
