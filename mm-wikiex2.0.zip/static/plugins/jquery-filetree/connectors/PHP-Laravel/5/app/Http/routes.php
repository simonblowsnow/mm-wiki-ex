<?php


Route::any('/you-route-name', 'FileTreeController@index');